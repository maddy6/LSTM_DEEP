# -*- coding: utf-8 -*-
"""
Created on Tue Jan 15 22:24:21 2019

@author: mayur.v
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Jan 11 11:37:36 2019

@author: mayur.v
"""

import pandas as pd
import re
import ast
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score

# read json into a dataframe
df =pd.read_csv("C:/Users/mayur.v/Desktop/BHGE/Named_Entity_Exatraction_POS3.csv",delimiter = ',',encoding = 'latin1')
len(df)
# print schema
print("Schema:\n\n",df.dtypes)
print("Number of questions,columns=",df.shape)
list(df)
df1 = df[['Case.Number','Named_Entity']]
df1.head()

CN = df['Case.Number']
PD = df['Problem.Description']

ner = []
for i in range(0,len(df['Named_Entity'])):
    print(i)
    ner.append(df['Named_Entity'][i])

vectorizer = TfidfVectorizer(stop_words='english')

X = vectorizer.fit_transform(df['Named_Entity'].values.astype('U'))

true_k = 15
model = KMeans(n_clusters=true_k, init='k-means++', max_iter=100, n_init=1)
model.fit(X)

print("Top terms per cluster:")
order_centroids = model.cluster_centers_.argsort()[:, ::-1]
terms = vectorizer.get_feature_names()
for i in range(true_k):
    print("Cluster %d:" % i),
    for ind in order_centroids[i, :10]:
        print(' %s' % terms[ind]),
    print
    
clusters = model.labels_.tolist()
frame=pd.DataFrame(idea,index=[clusters], columns=['Case_Number','Problem.Description','Named_Entity','Cluster']) # Converting it into a dataframe.
idea={'Case_Number':CN,'Problem.Description':PD, 'Named_Entity':ner, 'Cluster':clusters} #Creating dict having doc with the corresponding cluster number.
frame.to_csv('C:/Users/mayur.v/Desktop/BHGE/Cluster_output1.csv')

idea={'Named_Entity':ner, 'Cluster':clusters} #Creating dict having doc with the corresponding cluster number.
frame=pd.DataFrame(idea,index=[clusters], columns=['Named_Entity','Cluster']) # Converting it into a dataframe.
frame.to_csv('C:/Users/mayur.v/Desktop/BHGE/Cluster_output_NER.csv')

frame1 = pd.DataFrame(df[['Case.Number', 'Problem.Description']],frame)
print("\n")
print(frame) #Print the doc with the labeled cluster number.
print("\n")
print(frame['Cluster'].value_counts()) #Print the counts of doc belonging to each cluster.


Y = vectorizer.transform(["gtg customer"])
prediction = model.predict(Y)
print(prediction)

import nltk
words = set(nltk.corpus.words.words())
sent = "Io andiamo to the beach with my amico."
" ".join(w for w in nltk.wordpunct_tokenize(sent) \
         if w.lower() in words or not w.isalpha())

sent = 'signal,slwcrnk_rt,slwcrnk_rt slow crank,list,markup,customer,serial communication list,page,refer,communication,remaining,serial,time,crank,slow'

m = re.search("[a-zA-Z]+", sent)
print("".join(re.sub("[a-zA-Z]+","",sent)))

import enchant

w = re.sub("[a-zA-Z]+", "" , sent)

if re.match(r"[a-zA-Z]+", sent):
    re.sub("[a-zA-Z]+", "" , sent)
    print("yes")

e = [x for x in sent.split(',')]
e1 = []   
for i in range(0, len(e)):
    if re.match(r"[a-zA-Z]+", e[1]):
        print(index('i'))
        e1.append("".join(re.sub("","",e[i])))

regex = re.compile(".*_",
#                   
#ph = re.compile(r'_') 
#mo = ph.search(sent) 
#print(mo.group())

aa = []
for i in range(0,len(e)):
    if re.match(r"[a-zA-Z]+", e[i]):
        sent = re.sub(r".*_.*","", e[i])
        #str_list = list(filter(None, str_list))
        aa.append(''.join(sent))
            
    

aa = [x for x in aa if x != '']


