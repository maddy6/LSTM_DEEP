# -*- coding: utf-8 -*-
"""
Created on Thu Jan 10 18:50:57 2019

@author: mayur.v
"""

import nltk
doc = '''Andrew Yan-Tak Ng is a Chinese American computer scientist.
He is the former chief scientist at Baidu, where he led the company's
Artificial Intelligence Group. He is an adjunct professor (formerly 
associate professor) at Stanford University. Ng is also the co-founder
and chairman at Coursera, an online education platform. Andrew was born
in the UK in 1976. His parents were both from Hong Kong.'''

import pandas as pd
import re
import ast
from nltk import ne_chunk, pos_tag, word_tokenize
from nltk.tree import Tree

df_idf=pd.read_csv("C:/Users/mayur.v/Desktop/BHGE/test1.csv",delimiter = ',',encoding = 'latin1')
df_idf.head()
list(df_idf)

def pre_process(text):
    
    # lowercase
    #text=text.lower()
    
    #remove tags
    text=re.sub("&lt;/?.*?&gt;"," &lt;&gt; ",text)
    
    # remove special characters and digits
    text=re.sub("(\\d|\\W)+"," ",text)
    
    return text
 
type(df_idf['Problem.Description']) = df_idf['Problem.Description'].apply(lambda x:pre_process(x))
 

# tokenize doc
tok = []
for i in range(0,len(df_idf['Problem.Description'])):
    print(i)
    tokenized_doc = nltk.word_tokenize(df_idf['Problem.Description'][i])
    tok.append(tokenized_doc)
len(tok[1])
# tag sentences and use nltk's Named Entity Chunker
tag = []
for j in range(0,len(tok)):
    print(j)
    tagged_sentences = nltk.pos_tag(tok[j])
    tag.append(tagged_sentences)

chun = []
for k in range(0,len(tag)):
    print(k)
    ne_chunked_sents = nltk.ne_chunk(tag[k])
    chun.append(ne_chunked_sents)

chun[1]
# extract all named entities
named_entities = []
for ii in range(0,len(chun)):
    if hasattr(ii, 'label'):
        entity_name = ' '.join(c[0] for c in chun[ii].leaves()) #
        entity_type = ii.label() # get NE category
        named_entities.append((entity_name, entity_type))
print(named_entities)
ii=1

named_entities = []
for tagged_tree in ne_chunked_sents:
    
    entity_name = ' '.join(c[0] for c in tagged_tree.leaves()) #
    entity_type = tagged_tree.label() # get NE category
    named_entities.append((entity_name, entity_type))
print(named_entities)

chun[1].leaves()

tokenized_doc = nltk.word_tokenize(text)
 
# tag sentences and use nltk's Named Entity Chunker
tagged_sentences = nltk.pos_tag(tokenized_doc)
ne_chunked_sents = nltk.ne_chunk(tagged_sentences)
 
text = "During  4k  Inspection on PGT25+ G4, we have found sand in the  air inlet plenum. Kindly refer to the attached pictures and  please check and advise the way forward."


input=["he and Chazz duel with all keys on the line."]
from ICE import CollocationExtractor
extractor = CollocationExtractor.with_collocation_pipeline(“T1” , bing_key = “Temp”,pos_check = False)
print(extractor.get_collocations_of_length(input, length = 3))

text = df_idf['Problem.Description'][1]
import nltk
for sent in nltk.sent_tokenize(text):
   for chunk in nltk.ne_chunk(nltk.pos_tag(nltk.word_tokenize(sent))):
      if hasattr(chunk, 'label'):
         print(chunk.label(), ','.join(c[0] for c in chunk))
         
from fuzzywuzzy import fuzz
from fuzzywuzzy import process    
t = "Punch,Wiring Diagram,Item Sheet"
t1 = "Punch,Wiring Diagram,Item Sheet Additional"
t2 = "Punch,Wiring Diagram,Item Sheet,RTD Terminal,Item Sheet RTD"

fuzz.ratio(t, t1, t2)

from scipy import spatial

dataSetI = [3, 45, 7, 2]
dataSetII = [2, 54, 13, 15]
result = 1 - spatial.distance.cosine(dataSetI, dataSetII)


def get_continuous_chunks(text):
     chunked = ne_chunk(pos_tag(word_tokenize(text)))
     continuous_chunk = []
     current_chunk = []
     for i in chunked:
             if type(i) == Tree:
                     current_chunk.append(" ".join([token for token, pos in i.leaves()]))
             elif current_chunk:
                     named_entity = " ".join(current_chunk)
                     if named_entity not in continuous_chunk:
                             continuous_chunk.append(named_entity)
                             current_chunk = []
             else:
                     continue
     return continuous_chunk