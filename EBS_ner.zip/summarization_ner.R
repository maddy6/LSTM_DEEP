setwd('C:/Users/mayur.v/Desktop/BHGE/')

library(plyr)
library(dplyr)
library(data.table)
library(Matrix)
library(stringr)
library(syuzhet)

library(tm)
#library(openNLP)
library(rvest)
library(quanteda)
#library(qdap)
library("doSNOW")

library("doParallel") 

df<- data.frame( fread("BHGE_Dataset.csv", stringsAsFactors = FALSE))
type(df$Problem.Description)
df$Problem.Description<-gsub("\r\n", " ", df$Problem.Description)
df$Problem.Description<-gsub("\n", " ", df$Problem.Description)
df$Problem.Description<-gsub("\t", "", df$Problem.Description)

df$Problem.Description[1]



df$Problem.Description = gsub("[^[:alnum:][:blank:]+?&/\\-]", "", df$Problem.Description)

prob_desc = list()

for(i in 1:length(df$Problem.Description)){
  
  if(nchar(df$Problem.Description[i])>0){
    prob_desc[[i]] = df$Problem.Description[i]
  }else{
    prob_desc[[i]] = "No Sufficient data available"
  }
}

prob_description = unlist(prob_desc)


naive_sumly <- function(text, method = "bing")
{
  
  agg_txt <- text
  txt_string <- as.String(agg_txt)
  word_ann <- Maxent_Word_Token_Annotator()
  sent_ann <- Maxent_Sent_Token_Annotator()
  txt_annotations <- annotate(txt_string, list(sent_ann, word_ann))
  txt_doc <- AnnotatedPlainTextDocument(agg_txt, txt_annotations)
  
  st <- sents(txt_doc)
  wt <- words(txt_doc)
  
  sens <- get_sentences(agg_txt)
  
  words_per_sens<-llply(st, function(x){
    
    temp <- x
    
    return(temp)
  })
  
  
  if (length(sens) > 1)
  {
    sim_mat <- foreach(a = words_per_sens, .combine = "cbind") %:%
      foreach(b = words_per_sens, .combine = "c") %dopar% {
        length(intersect(a, b))/((length(a) + length(b))/2)
      }
    spars_sim_mat <- Matrix(sim_mat, sparse = T)
    if(colSums(spars_sim_mat)>1){
      diag(spars_sim_mat) <- 1
      sens_sim <- colSums(spars_sim_mat)-1
      dat <- data.table(sentence = sens, total_sim = colSums(spars_sim_mat)-1)
      
      paras <- unlist(strsplit(agg_txt, split = "\r\n", fixed = T))
      
      best_sens <- rep(NA, length(paras))
      max_para_vals <- rep(NA, length(paras))
    }
    
    if(colSums(spars_sim_mat)<=1){
      sens_sim <- colSums(spars_sim_mat)
      dat <- data.table(sentence = sens, total_sim = colSums(spars_sim_mat))
      
      paras <- unlist(strsplit(agg_txt, split = "\r\n", fixed = T))
      
      best_sens <- rep(NA, length(paras))
      max_para_vals <- rep(NA, length(paras))
    }
    
    i <- 1
    for (p in paras)
    {
      
      best_sen <- NA
      max_para_val <- 0
      para_sens <- get_sentences(p)
      for (s in para_sens)
      {
        m <- dat[grepl(s, sentence, fixed = TRUE),]$total_sim
        if (m > max_para_val)
        {
          max_para_val <- m
          best_sen <- as.character(s)
        }
        else
        {
          max_para_val <- max_para_val
          best_sen <- best_sen
        }
      }
      best_sens[i] <- best_sen
      max_para_vals[i] <- max_para_val
      i <- i + 1
      
    }
    best_sens <- best_sens[which(max_para_vals != 0)]
    max_para_vals <- max_para_vals[which(max_para_vals != 0)]
    
    return(list(summary = best_sens, max_sim_values = max_para_vals))
  }
  else
  {
    return(text)
  }
}

naive_sumly(prob_description[1])
library(NLP)

