# -*- coding: utf-8 -*-
"""
Created on Tue Jan 15 22:00:56 2019

@author: mayur.v
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Jan 15 15:24:53 2019

@author: mayur.v
"""

import numpy as np
import pandas as pd
import nltk
from nltk.tokenize import sent_tokenize
#nltk.download('punkt') # one time execution
import re
from nltk import ne_chunk, pos_tag, word_tokenize
from nltk.tree import Tree

df = pd.read_csv("C:/Users/mayur.v/Desktop/BHGE/Clustering_doc.csv",delimiter = ',',encoding = 'latin1')
df.head() 


def pre_process(text):
    
    # lowercase
    #text=text.lower()
    
    #remove tags
    text=re.sub("(\\d|\\W)+"," ",text)
    
    text = re.sub(r'\b[A-Z]+\b', '', text)
    #text = re.sub(r',','',text)
    #text = re.sub(r';','',text)
    text = ' '.join( [w for w in text.split() if len(w)>2] )
    # remove special characters and digits
    
    return text
    
df['Problem.Description'] = df['Problem.Description'].apply(lambda x:pre_process(x))


## Remove Stop Words
#stop_words = set(stopwords.words('english')) 

#filtered_sentence = [w for w in word_tokens if not w in stop_words] 

def get_continuous_chunks(text):
     chunked = ne_chunk(pos_tag(word_tokenize(text)))
     continuous_chunk = []
     current_chunk = []
     for i in chunked:
             if type(i) == Tree:
                     current_chunk.append(" ".join([token for token, pos in i.leaves()]))
             elif current_chunk:
                     named_entity = " ".join(current_chunk)
                     if named_entity not in continuous_chunk:
                             continuous_chunk.append(named_entity)
                             current_chunk = []
             else:
                     continue
     return continuous_chunk
     
a = []
for i in range(0,len(df['Problem.Description'])):
    print(i)
    a.append(get_continuous_chunks(df['Problem.Description'][i]))

s = []
for i in range(0,len(a)):
    s.append(','.join(a[i]))

#text = 'On Turbo  generator; GTG  A,B,C,D , Since Korea installation and load running  test ,the Brush safety  Air Generator pressurization system is not working properly .In fact at each fire start up , when the unit try to reach Idle speed the trip  for low pressure on the pressurization air system occurred. During  this  attempts to fire , several leaks where fuond and fixed   but the system still tripping when the Unit is Accelerating to Idle speed . It seems that on this stage the generator need more Flow.  To  ensure that the lack of flow could be a possible cause, we simply forced the signal that Trip us and after idle  speed where removed without and problem of tripping  allowing us to do a Normal stop  of the Unit. The Air Pressurization system ( EXPO BOX)  is a Brush design and not controll by MKVIe/MKVIes'
#text = text.lower()
#q = word_tokenize(text)
#tagged = nltk.pos_tag(q)
#list(filter(lambda x: x[1] == 'NNP'or x[1] == 'NN', tagged))
### POS Tag Approach 
#text = sentences[0]
word_tokenise = []
for i in range(0,len(df['Problem.Description'])):
    print(i)
    word_tokenise.append(word_tokenize(df['Problem.Description'][i]))
    
pos_tag = []
for i in range(0,len(word_tokenise)):
    print(i)
    pos_tag.append(nltk.pos_tag(word_tokenise[i]))
    
        
fil_pos = []
for i in range(0,len(pos_tag)):
    print(i)
    #fil_pos.append(list(filter(lambda x: x[1] == 'NNP' or x[1] == 'NN', pos_tag[i])))
    fil_pos.append(list(filter(lambda x: x[1] == 'NNP' or x[1] == 'VBG' or x[1] == 'VBP', pos_tag[i])))
    #fil_pos.append(pos_list)
    
 
s1[1] = []
for i in range(0,len(fil_pos)):
    s1.append([i[0] for i in fil_pos[i]])
       

NER[1] = []
for i in range(0,len(a)):
    print(i)
    NER.append(set(a[i]+s1[i]))

len(NER) 

Named_Entity[1] = []
for i in range(0,len(NER)):
    print(i)
    Named_Entity.append(','.join(NER[i]))
    
from nltk.chunk import conlltags2tree, tree2conlltags
from nltk import word_tokenize, pos_tag, ne_chunk

ss = ' '.join(a[1]+s1[1])
sentence = "reach turbo cause korea fire air need fact pressurization normal air generator,load,stage,generator,lack,flow,system,mkvie,fuond,speed,unit,start,signal,brush,pressure,accelerating,idle,mkvies,installation,brush mkvie,trip,safety,design,problem"
sentence = "During Inspection Brush have found sand the air inlet plenum Kindly refer the attached pictures and please check and advise the way forward"
#sentence = "During Inspection running Air Generator Normal Trip fire tripping Brush"
sentence = "Turbo generator Since Korea installation and load running test the Brush safety Air Generator pressurization system not working properly fact each fire start when the unit try reach Idle speed the trip for low pressure the pressurization air system occurred During this attempts fire several leaks where fuond and fixed but the system still tripping when the Unit Accelerating Idle speed seems that this stage the generator need more Flow ensure that the lack flow could possible cause simply forced the signal that Trip and after idle speed where removed without and problem tripping allowing Normal stop the Unit The Air Pressurization system Brush design and not controll MKVIe MKVIes"
#sentence = sentence.lower()
#sentence = ss
ne_tree = ne_chunk(pos_tag(word_tokenize(sentence)))
iob_tagged = tree2conlltags(ne_tree) 

a2= list(filter(lambda x: (x[1] == 'NNP' or x[1] == 'VBG') and (x[2] == 'O' or x[2] == 'I-PERSON' or x[2] == 'B-PERSON'), iob_tagged))


Named_Entity[1] = [x.lower() for x in Named_Entity]

Named_Entity = pd.DataFrame(Named_Entity)
Named_Entity.columns = ['Named Entity']

def unique_list(l):
    ulist = []
    [ulist.append(x) for x in l if x not in ulist]
    return ulist
    
len(n1[12]) = []
for i in range(0,len(Named_Entity)):
    n1.append(','.join(unique_list(Named_Entity[i].split(','))))


Named_Entity = pd.DataFrame(n1)
Named_Entity.columns = ['Named Entity']








Named_Entity = [x.lower() for x in Named_Entity]

Named_Entity = pd.DataFrame(Named_Entity)
Named_Entity.columns = ['Named Entity']

def unique_list(l):
    ulist = []
    [ulist.append(x) for x in l if x not in ulist]
    return ulist
    
n1[1] = []

n11[1] = []
for i in range(0,len(n1)):
    n11.append(n1[i].split(','))
     
type(n2[1]) = []
for i in range(0,len(n11)):
    n2.append(','.join(n11[i]))

    
for i in range(0,len(Named_Entity)):
    n1.append(','.join(unique_list(Named_Entity[i].split(','))))

lat_list = [item for sublist in n11 for item in sublist]
 
aa = []
for i in range(0,len(n2)):
        sent = re.sub(r".*_.*","", n2[i])
        #str_list = list(filter(None, str_list))
        aa.append(''.join(sent))
            
    
i=1
aa = [x for x in aa if x != '']




from fuzzywuzzy import fuzz
from fuzzywuzzy import process

aaa = [x for x in n1[1].split(',')]
len(aaa)

process.extract(aaa[1:10], aaa)
process.extractOne(aaa[5], aaa)
#words = word_tokenize(n1[1])
#
#for w in words:
#    print(ps.stem(w))

#from stemming.porter2 import stem
from nltk.stem import PorterStemmer
#len(count(r[1]) = []
#for i in range(0, len(Named_Entity)):
#    r.append(Named_Entity[i].split(','))
#
#c[1] = []
#for i in range(0, len(Named_Entity)):
#    c.append(list(map(len,Named_Entity[i].split(','))))
#
#ff[152] = []
#for i in range(0, len(c)):
#    if len(c[152])>2:
#        ff.append(Named_Entity[i])
#    
#rr[157] = []
#for i in range(0, len(r)):
#    rr.append(' '.join(r[i]))
#    
#t = ' '.join( [w for w in rr if len(w)>1] )
    
df['Named_Entity'] = Named_Entity
df.head()
df.to_csv('C:/Users/mayur.v/Desktop/BHGE/Named_Entity_Exatraction_POS2.csv')

#Named_entity = []
#for i in range(0,len(NER))
#list(map(lambda x:x.lower(),NER[7])) 


r = "Please refer to the attached list for this issue."
rr = word_tokenize(r)
rr = nltk.pos_tag(rr)

from nltk.stem import PorterStemmer 
from nltk.tokenize import word_tokenize 
   
ps = PorterStemmer() 
ps.stem('cause')
NER[7] = list(NER[7])
NER[7] = list(map(lambda x:x.lower(),NER[7])) 
NER[7] = NER[7].lower()
for w in NER[7]: 
    print(w, " : ", ps.stem(w))
    
tokenized = word_tokenize(df['Problem.Description'][1])
tagged = nltk.pos_tag(tokenized)
tagged
set(list(filter(lambda x: x[1] == 'NNP' or x[1] == 'VBG' or x[1] == 'NN', tagged)))

def get_continuous_chunks(text):
     chunked = ne_chunk(pos_tag(word_tokenize(text)))
     continuous_chunk = []
     current_chunk = []
     for i in chunked:
             if type(i) == Tree:
                     current_chunk.append(" ".join([token for token, pos in i.leaves()]))
             elif current_chunk:
                     named_entity = " ".join(current_chunk)
                     if named_entity not in continuous_chunk:
                             continuous_chunk.append(named_entity)
                             current_chunk = []
             else:
                     continue
     return continuous_chunk
     
get_continuous_chunks(text)

text = ["Turbo generator Since Korea installation and load running test the Brush safety Air Generator pressurization system not working properly fact each fire start when the unit try reach Idle speed the trip for low pressure the pressurization air system occurred During this attempts fire several leaks where fuond and fixed but the system still tripping when the Unit Accelerating Idle speed seems that this stage the generator need more Flow ensure that the lack flow could possible cause simply forced the signal that Trip and after idle speed where removed without and problem tripping allowing Normal stop the Unit The Air Pressurization system Brush design and not controll MKVIe MKVIes"]

text = "way check air inlet kindly inspection plenum"

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk import word_tokenize
from nltk.stem.porter import PorterStemmer

def tokenize(text):
    tokens = word_tokenize(text)
    stems = []
    for item in tokens: stems.append(PorterStemmer().stem(item))
    return stems

# your corpus
text = ["This is your first text book", "This is the third text for analysis", "This is another text"]
# word tokenize and stem
tokens = word_tokenize(text)
text = [" ".join(tokens(text.lower()))]
text = [" ".join(tokens)]
vectorizer = TfidfVectorizer()
matrix = vectorizer.fit_transform(text).todense()
# transform the matrix to a pandas df
matrix = pd.DataFrame(matrix, columns=vectorizer.get_feature_names())
# sum over each document (axis=0)
top_words = matrix.sum(axis=0).sort_values(ascending=False)



